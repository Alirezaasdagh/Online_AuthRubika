import asyncio
import json
import os
import os.path
from random import randint
from threading import Thread
from urllib import request

import pyuseragents
import requests
from rich import print as prints

from cipherx.hash import en

# = = = = = = = = = = = = [ NONE ] = = = = = = = = = = = = #

plat    = pyuseragents.random()
headers = {'accept': 'application/json, text/plain, */*', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9', 'content-length': '338', 'content-type': 'text/plain', 'origin': 'https://web.rubika.ir', 'referer': 'https://web.rubika.ir/', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="104"' , 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Linux"', 'sec-fetch-dest': 'empty', 'sec-fetch-mode': 'cors', 'sec-fetch-site': 'cross-site', 'user-agent': plat}
site    = 'https://messengerg2c60.iranlms.ir/' 
shad    = 'https://shadmessenger27.iranlms.ir/'
# = = = = = = = = = = = = [ NONE ] = = = = = = = = = = = = #

def tnFile(file_name:bytes) -> dict:
    import base64
    import io

    import PIL.Image
    im, output = PIL.Image.open(io.BytesIO(file_name)), io.BytesIO()
    width, height = im.size
    im.save(output, format='PNG')
    im_data = output.getvalue()
    image_data = base64.b64encode(im_data)
    if not isinstance(image_data, str): image_data = image_data.decode()
    return image_data

def size_image(file_name:bytes):
    import io

    import PIL.Image
    im = PIL.Image.open(io.BytesIO(file_name))
    width, height = im.size
    return [width , height]

class ClientRubika:
    def __init__(self, auth: str, welcome: bool = True, threading: bool = True):
        self.__auth    = auth
        self.__en      = en(auth)
        self.__welcome = welcome
        self.__thread  = threading
        if self.__welcome != False:
            print('\033[91mR\033[94mUBIK\033[91mA\033[97m~\033[91mC\033[94mipher\033[91mX\033[0m')

    def SendCode(self, phone: str, send_type: str = "SMS", key: str = None):
        methods = {'method': 'sendCode', 'input': {'phone_number': phone, 'send_type': send_type, "pass_key": key}, 'client': {'app_name': 'Main', 'app_version': '4.1.7', 'platform': 'Web', 'package': 'web.rubika.ir', 'lang_code': 'fa'}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","tmp_session": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))

    def Register(self, authX):
        data_enc = self.__en.encrypt(json.dumps({
            "app_version": "MA_3.1.0",
            "device_hash": "250118664537361040511210153736",
            "device_model": "CipherX",
            "lang_code": "fa",
            "system_version": "SDK 23",
            "token": "",
            "token_type": "Firebase"
        }))

        payload = {
            "api_version": "4",
            "auth": authX,
            "client": {
                "app_name": "Main",
                "app_version": "3.1.0",
                "lang_code": "fa",
                "package": "ir.resaneh1.iptv",
                "platform": "Android"
            },
            "data_enc": data_enc,
            "method": "registerDevice"
        }

        return requests.post(site, json=payload).text

    def EditMessage(self, object_guid: str , message_id: str, newText: str):
        methods = {"method":"editMessage","input":{"object_guid":object_guid,"message_id":message_id,"text":newText},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def SendMessage(self, chat_id: str, message):
    
        methods = {"method":"sendMessage","input":{"object_guid":chat_id,"rnd":"863042","text":message},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def getChatUpdates(self):
        methods = {"method":"getChatsUpdates","input":{"state":randint(0, 99999999)},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}  
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def getMessages(self, object_guid: str = None, min_id: int = 0, sort: str = "FromMin" or "FromMax"):
        methods = {"method":"getMessages","input":{"object_guid":object_guid,"sort":sort,"min_id":min_id},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def message(self):
        methods = {"method":"getChatsUpdates","input":{"state":1666985507},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
                
    def DeleteMessage(self, object_guid: str, message_id: str):
        methods = {"method":"deleteMessages","input":{"object_guid":object_guid,"message_ids":[message_id],"type":"Local"},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def setAdminGroup(self, guid_group, guid_member):
        methods = {"method":"setGroupAdmin","input":{"group_guid":guid_group,"member_guid":guid_member,"action":"SetAdmin","access_list":["ChangeInfo","PinMessages","DeleteGlobalAllMessages","BanMember","SetJoinLink","SetAdmin","SetMemberAccess"]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))

    def setAdminChannel(self, guid_channel, guid_member):
        methods = {"method":"setChannelAdmin","input":{"channel_guid":guid_channel,"member_guid":guid_member,"action":"SetAdmin","access_list":["ChangeInfo","ViewMembers","ViewAdmins","PinMessages","SendMessages","EditAllMessages","DeleteGlobalAllMessages","AddMember","SetJoinLink"]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))

    def joinChannel(self, hash_link):
        while True:
            try:
                methods = {"method":"joinChannelByLink","input":{"hash_link":hash_link},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
                response = json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
                break
            except requests.exceptions.RequestException:
                pass
        return response

    def online(self, authX):
        while True:
            try:
                response = requests.post(json={"data":{},"method":"getUser","api_version":"2","auth":authX,"Messenger":{"app_name":"Main","package":"m.rubika.ir","app_version":"1.2.1","platform":"PWA"}},url='https://messengerg2c1.iranlms.ir/', headers=headers).text
                break
            except requests.exceptions.RequestException:
                pass
        return response
    
    def requestSendFile(self, file_name):
        if os.path.exists(file_name):
            formatFile = file_name.split('.')
            file_size = os.path.getsize(file_name)
            methods = {"method":"requestSendFile","input":{"file_name":file_name,"size":file_size,"mime":formatFile[1]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
            return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
        else:
            print('Not Found %s' %file_name)

    def sendImage(self, file_name, guid):
        if os.path.exists(file_name):
            formatFile = file_name.split('.')
            file_size = os.path.getsize(file_name)
            wid = size_image(open(file_name, 'rb').read())
            Image = tnFile(open(file_name, 'rb').read())     
            request_File =  {"method":"requestSendFile","input":{"file_name":file_name,"size":str(len(Image)),"mime":formatFile[1]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
            file = json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(request_File))}, headers=headers).text)['data_enc']))
            for part, index in enumerate(range(0, len(Image), 131072), start=1):
                data = Image[index: index + 131072]
                ase = {'auth': self.__auth,
                        'file-id': file['data']['id'],
                        'total-part': '1',
                        'part-number': '1',
                        'chunk-size': str(len(data)),
                        'access-hash-send': file['data']['access_hash_send']}
                file_main = requests.post(file['data']['upload_url'], data=data, headers=ase).json()
                methods = {"method":"sendMessage","input":{"object_guid":guid,"rnd":"617235","file_inline":{"dc_id":file['data']['dc_id'],"file_id":file['data']['id'],"type":"Image","file_name":file_name,"size":len(Image),"mime":formatFile[1],"thumb_inline":Image,"width":wid[0],"height":wid[1],"access_hash_rec":file_main['data']['access_hash_rec']}},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
                return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))


class ClientShad: 
    def __init__(self, auth: str, welcome: bool = True, threading: bool = True):
        self.__auth    = auth
        self.__en      = en(auth)
        self.__welcome = welcome
        self.__thread  = threading
        if self.__welcome != False:
            print(' 033[91mR 033[94mUBIK 033[91mA  033[97m~  033[91mC 033[94mipher 033[91mX 033[0m')

    def SendCode(self, phone: str, send_type: str = "SMS"):
        methods = {'method': 'sendCode', 'input': {'phone_number': phone, 'send_type': send_type}, 'client': {'app_name': 'Main', 'app_version': '3.2.3', 'platform': 'Web', 'package': 'web.shad.ir', 'lang_code': 'fa'}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(shad, json={"api_version": "5","tmp_session": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def SendMessage(self, chat_id: str, message):
        methods = {"method":"sendMessage","input":{"object_guid":chat_id,"rnd":"863042","text":message},"client":{"app_name":"Main","app_version":"3.2.3","platform":"Web","package":"web.shad.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(shad, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))

    def getMessages(self, object_guid: str = None, min_id: int = 0, sort: str = "FromMin" or "FromMax"):
        methods = {"method":"getMessages","input":{"object_guid":object_guid,"sort":sort,"min_id":min_id},"client":{"app_name":"Main","app_version":"3.2.3","platform":"Web","package":"web.shad.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(shad, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def DeleteMessage(self, object_guid: str, message_id: str):
        methods = {"method":"deleteMessages","input":{"object_guid":object_guid,"message_ids":[message_id],"type":"Local"},"client":{"app_name":"Main","app_version":"3.2.3","platform":"Web","package":"web.shad.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(shad, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))
    
    def setAdminGroup(self, guid_group, guid_member):
        methods = {"method":"setGroupAdmin","input":{"group_guid":guid_group,"member_guid":guid_member,"action":"SetAdmin","access_list":["ChangeInfo","PinMessages","DeleteGlobalAllMessages","BanMember","SetJoinLink","SetAdmin","SetMemberAccess"]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))

    def setAdminChannel(self, guid_channel, guid_member):
        methods = {"method":"setChannelAdmin","input":{"channel_guid":guid_channel,"member_guid":guid_member,"action":"SetAdmin","access_list":["ChangeInfo","ViewMembers","ViewAdmins","PinMessages","SendMessages","EditAllMessages","DeleteGlobalAllMessages","AddMember","SetJoinLink"]},"client":{"app_name":"Main","app_version":"4.1.7","platform":"Web","package":"web.rubika.ir","lang_code":"fa"}}
        return json.loads(self.__en.decrypt(json.loads(requests.post(site, json={"api_version": "5","auth": self.__auth,"data_enc": self.__en.encrypt(json.dumps(methods))}, headers=headers).text)['data_enc']))


