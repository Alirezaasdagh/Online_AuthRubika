import base64

from Crypto.Cipher import AES
from Crypto.Util import Padding


def secretWeb(auth: str):
    def secret(a: str) -> str:
        result: str = ''
        for i in a[16:24]+a[0:8]+a[24:32]+a[8:16]:
            if '0' <= i <= '9':
                result += chr(((ord(i) - 48 + 5) % 10) + 48)
                print(result)
            elif 'a' <= i <= 'z':
                result += chr(((ord(i) - 97 + 9) % 26) + 97)
                print(result)
        return result

    raw = Padding.pad(auth.encode('utf-8'), 16)
    data = base64.b64encode(AES.new(
        bytes(secret('weqrvmnxmnvljflksjlkjdsaoiuouopm'), 'utf-8'),
        2,
        bytes.fromhex('0' * 32)
        ).encrypt(raw)).decode()
    return data
